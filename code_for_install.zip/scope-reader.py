import subprocess as sp
import struct
import sys, os
import visa
import numpy as np
import DataLoader

delim = ',' #change default deliminator as needed
user = castells
location = icarusgpvm01.fnal.gov:/icarus/app/users/castells/my_test_area/waveform_analysis

def test_writeFile(filename):
	with open("%s.csv" % filename, "w") as file:
		for i in range(100):
			file.write("100%s29\n" % delim)


def readFile(filename):
	line_value = []
	with open(filename) as file:
		for line in file:
			line_value.append(line)
	
	return line_value


def parseFile(line):
	line_value = line.split(delim)
	line_value[len(line_value)-1] = line_value[len(line_value)-1].strip('\n')
	
	return line_value


def savePeaks(lines):
	h = []
	x = []
	y = []
	w = []
	n = []
	for i in lines:
		line_value = parseFile(lines[i])
		h.append(line_value[0])
		x.append(line_value[1])
		y.append(line_value[2])
		w.append(line_value[3])
		n.append(line_value[4])
	
	items = [h,x,y,w,n]
	return items


def saveAtts(lines):
	b = []
	s = []
	n = []
	p = []
	for i in lines:
		line_value = parseFile(lines[i])
		b.append(line_value[0])
		s.append(line_value[1])
		n.append(line_value[2])
		p.append(line_value[3])
	
	items = [b,s,n,p]
	return items


def fileLength(filename):
	count = 0
	with open(filename) as file:
		for line in file:
			count += 1
	
	return count - 1


def getWaveform(channel):
	#tells scope channel, encoding, # of data points, # of points to keep
	rm = visa.ResourceManager()
	scopeID = 'TCPIP0::192.168.230.71::INSTR'
	data_points = "10000"
	scope = rm.open_resource(scopeID)
	scope.write('DATa:SOURce %s' % (channel))
	scope.write('DATa:ENCdg RPB')
	scope.write('DATa:WIDth 1')
	scope.write('DATa:STARt 1')
	scope.write('DATa:STOP %s' % (data_points))

	ymult = float(((scope.query('WFMPRE:YMULT?')).split(' '))[1])
	yzero = float(((scope.query('WFMPRE:YZERO?')).split(' '))[1])
	yoff = float(((scope.query('WFMPRE:YOFF?')).split(' '))[1])
	xincr = float(((scope.query('WFMPRE:XINCR?')).split(' '))[1])

	scope.write('CURVE?')
	data = scope.read_raw()

	#the value for 13 accounts for and removes :CURV #510000
	ADC_wave = data[13:-1]

	ADC_wave = np.array(unpack('%sB' % len(ADC_wave),ADC_wave))

	#this is units of volts and milliseconds
	Volts = (ADC_wave - yoff) * ymult  + yzero
	Time = np.arange(0, xincr * len(Volts), xincr)

	#creates and fills numpy array (2x10000)
	data = np.empty(shape=(2, int(data_points)))

	#fill data array with voltage and time values
	data_iterator = 0
	for i in np.nditer(Volts):
		data[0,data_iterator] = i
		data_iterator += 1

	data_iterator = 0
	for i in np.nditer(Time):
		data[1,data_iterator] = i
		data_iterator += 1

	#writes data array to file in csv format
	filename = "%s.csv" % (channel)
	with open(filename, 'w+') as file:
		for i in range(len(data_points):
			line = str(data[1,i]) + "," + str(data[0,i])
			file.write(line + "\n")

	return channel


def uploadData():
	#	Order of entries for test information in test_stas.csv
	#	
	#	Operator				OP				string
	#	Waveform ID			WVID			int
	#	Test ID					TID				int
	#	Wire Number			WRN				int
	#	Wire Plane			WRP				int
	#	Channel ID			CHN_ID		int
	#	Chimney					CHM				string
	#	Input Chimney		I_CHM			string
	#	Input Cable			I_CBL			string
	#	Date						DT				string
	#	Comment					CM				string
	#
	
	test_stats = readFile("test_stats.csv")
	data = parseFile(test_stats[0])
	OP = data[0]
	WVID = int(data[1])
	TID = int(data[2])
	WRN = int(data[3])
	WRP = int(data[4])
	CHN_ID = int(data[5])
	CHM = data[6]
	I_CHM = data[7]
	I_CBL = data[8]
	DT = data[9]
	CM = data[10]
	
	print("\n" + "-" * 20)
	print("Operator: \t%s" % (OP))
	print("Waveform ID: \t%d" % (WVID))
	print("Test ID: \t%d" % (TID))
	print("Wire Number: \t%d" % (WRN + "+ next 3"))
	print("Wire Plane: \t%d" % (WRP))
	print("Channel ID: \t%d" % (CHN_ID))
	print("Chimney: \t%s" % (CHM))
	print("Input Chimney: \t%s" % (I_CHM))
	print("Input Cable: \t%s" % (I_CBL))
	print("Date: \t\t%s" % (DT))
	print("Comment: \t%s" % (CM))
	print("-" * 20 + "\n")
	
	verify = raw_input("Current test parameters set. Save test data to database? (Y/n): ")
	check = True
	
	sp.check_output(['mv','waveforms.root','test_%s_%s.root' % (WRP,WRN))

	row_peak = {
		'waveform_id': WVID,
		'test_id': TID,
		'peak_id': peak_id,
		'height': height,
		'width': width,
		'peak_time': x_value,
	}

	password = os.environ.get("LOADER_PWD", "xxxxxxxxx")
	url_pulse = "https://dbweb5.fnal.gov:8443/hdb/icarusdev/D/test_pulse_mappings"
	url_wave = "https://dbweb5.fnal.gov:8443/hdb/icarusdev/D/continuity_test_waveforms"
	url_peak = "https://dbweb5.fnal.gov:8443/hdb/icarusdev/D/continuity_peak_waveforms"
	group = "Continuity Tables" 
	table_pulse = "test_pulse_mappings"
	table_wave = "continuity_test_waveforms"
	table_peak = "continuity_peak_waveforms"
	
	while(check == True):
		if(verify == "Y"):
			check = False
			wave_atts = saveAtts(readFile('waveform_attributes.csv'))
			WV_BASELINE = wave_atts[0]
			WV_NOISE = wave_atts[1]
			WV_PEAKS = wave_atts[3]
			
			peak_data = savePeaks(readFile('signal_stats.csv'))
			P_ID = peak_data[4]
			P_XVALUE = peak_data[1]
			P_HEIGHT = peak_data[2]
			P_WIDTH = peak_data[3]
			
			dataLoader_pulse = DataLoader(password, url_pulse, group, table_pulse)
			dataLoader_pulse.addRow(row_pulse)
			dataLoader_pulse.clearRows()
			
			for i in range(len(W_BASELINE)):
				WVID += i*1
				baseline = WV_BASELINE[i]
				std_dev = WV_NOISE[i]
				peaks = WV_PEAKS[i]
				
				row_wave = {
					'waveform_id': WVID,
					'test_id': TID,
					'test_date': DT,
					'wire_plane': WRP,
					'wire_number': WRN,
					'baseline': WV_BASELINE,
					'standard_deviation': WV_NOISE,
					'histogram': open("CH%s.gif" % i, "rb"),
					'fft': open("CH%sFFT.gif" % i, "rb"),
					'operator': OP,
				}
				
				dataLoader_wave = DataLoader(password, url_wave, group, table_wave)
				dataLoader_wave.addRow(row_wave)
				dataLoader_wave.clearRows()
				
				for i in range(len(P_XVALUE)):
					peak_id = P_ID[i]
					height = P_HEIGHT[i]
					width = P_WIDTH[i]
					x_value = P_XVALUE[i]
					
					row_pulse = {
						'wire_plane': WRP,
						'wire_number': WRN,
						'chimney': CHM,
						'input_chimney': I_CHM,
						'input_cable': I_CBL,
					}
					
					dataLoader_peak = DataLoader(password, url_peak, group, table_peak)
					dataLoader_peak.addRow(row_peak)
					dataLoader_peak.clearRows()
			
			with open("test_stats.csv", "w+") as file:
				file.write(OP,WVID,TID,WRN,WRP,CHN_ID,CHM,I_CHM,I_CBL,DT,CM)
			
			(retVal1, code1, text1) = dataLoader_pulse.send()
			(retVal2, code2, text2) = dataLoader_wave.send()
			(retVal3, code3, text3) = dataLoader_peak.send()

			if retVal1 and retVal2 and retVal3:
				#successfully uploaded data
				pass
			else:
				print "Failed!" 
				print code1
				print code2
				print code3
				print text1
				print text2
				print text3
				sys.exit(1)
		
		elif(verify == "n"):
			check = False
			print("Test data not saved to database. Access test results in corresponding files or run test again.")
		
		else:
			print("Select a valid response... \n")


def fullAnalysis():
	#run py-VISA code here
	ch1_name = getWaveform("CH1")
	ch2_name = getWaveform("CH2")
	ch3_name = getWaveform("CH3")
	ch4_name = getWaveform("CH4")

	#run ROOT/C++ code here (via command line)
	sp.check_output(['scp','./CH1.csv','%s@icarusgpvm01.fnal.gov:%s/' % (user,location)])
	sp.check_output(['scp','./CH2.csv','%s@icarusgpvm01.fnal.gov:%s/' % (user,location)])
	sp.check_output(['scp','./CH3.csv','%s@icarusgpvm01.fnal.gov:%s/' % (user,location)])
	sp.check_output(['scp','./CH4.csv','%s@icarusgpvm01.fnal.gov:%s/' % (user,location)])

	sp.Popen(['ssh','-tt','%s@icarusgpvm01.fnal.gov' % user,'source mv2ic.sh waveform_analysis n; root -b -q -l run_slow.c'])

	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/signal_stats.csv' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/waveform_attributes.csv' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/waveforms.root' % (user,location),'.'])

	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH1.gif','./%s' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH1FFT.gif','./%s' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH2.gif','./%s' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH2FFT.gif','./%s' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH3.gif','./%s' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH3FFT.gif','./%s' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH4.gif','./%s' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH4FFT.gif','./%s' % (user,location),'.'])

	sp.check_output(['reset'])
	sp.check_output(['clear'])

	#uploadData()

def quickAnalysis():
	#run py-VISA code here
	ch1_name = getWaveform("CH1")
	ch2_name = getWaveform("CH2")
	ch3_name = getWaveform("CH3")
	ch4_name = getWaveform("CH4")

	#run ROOT/C++ code here (via command line)
	sp.check_output(['scp','./CH1.csv','%s@icarusgpvm01.fnal.gov:%s/' % (user,location)])
	sp.check_output(['scp','./CH2.csv','%s@icarusgpvm01.fnal.gov:%s/' % (user,location)])
	sp.check_output(['scp','./CH3.csv','%s@icarusgpvm01.fnal.gov:%s/' % (user,location)])
	sp.check_output(['scp','./CH4.csv','%s@icarusgpvm01.fnal.gov:%s/' % (user,location)])

	sp.Popen(['ssh','-tt','%s@icarusgpvm01.fnal.gov' % user,'source mv2ic.sh waveform_analysis n; root -b -q -l run_fast.c'])

	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/signal_stats.csv' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/waveform_attributes.csv' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/waveforms.root' % (user,location),'.'])

	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH1.gif','./%s' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH2.gif','./%s' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH3.gif','./%s' % (user,location),'.'])
	sp.check_output(['scp','%s@icarusgpvm01.fnal.gov:%s/CH4.gif','./%s' % (user,location),'.'])

	sp.check_output(['reset'])
	sp.check_output(['clear'])

	#uploadData()

quickAnalysis()